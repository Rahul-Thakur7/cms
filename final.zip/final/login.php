<?php 
header('location:index.php#login_form');
 ?>