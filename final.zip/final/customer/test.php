<?php  $timezone = date_default_timezone_get();
echo "The current server timezone is: " . $timezone;
?>